<meta charset ="utf-8">
<?
    $id = $_GET['nick'];
    //겟 방식으로 닉네임을 받음
    if(!$id)
    {
        echo("닉네임을 입력하세요.");
    }
    else
    {
        include "dbconn.php";
        mysqli_query($connect,'set names utf8');
        //db 접속, 한글 깨질까봐 해준것
        //한글 안깨지면 지워도 됨

        $sql = "select * from join_mem where nick = '$nick'";

        $result = mysqli_query($connect,$sql);
        $num_record = mysqli_num_rows($result);
        //record총 개수를 샘

        if($num_record)
        {
            echo "닉네임이 중복됩니다! <br>";
            echo "다른 닉네임을 사용하세요.<br>";
        }
        else{
            //numrecord 가 0이면
            echo "사용가능한 닉네임입니다.";
        }

        mysqli_close($connect);
    }
?>