<? 
	session_start(); 
	//로그인 상태 유지
?>
	<div id="top_login">
<?
    if(!$_SESSION['userid'] )
	//userid 는 SESSION array 에 있는 value 의 index
	//SESSION 에 userid 가 없으면
	{
?>
          <a href="login_form.php">Login</a>
		   <!--html 에 Login을 보이고 누르면 login_form.php로 가라  -->
           <a href = "member_conditions.html">회원가입</a>
<?
	}
	else
	{
?>
		<?=$_SESSION['userid']?> |
		<!-- phpSESSION 에 userid있으면  -->
		<a href="logout.php">Logout</a> |
		<!--logout 보이고 누르면 logout.php로 가라-->
        <a href = "member_delete.php">회원탈퇴</a> |
        <a href = "modify.php">정보수정</a>

<?
	}
?>
	  
     </div>
  
