<meta charset ="utf-8">
<?
    $id = $_GET['id'];
    //겟 방식으로 아이디를 받음
    if(!$id)
    {
        echo("아이디를 입력하세요.");
        //아이디가 없으면 아이디를 입력하세요 라고 써라
    }
    else
    {
        //아이디가 있으면
        include "dbconn.php";
        mysqli_query($connect,'set names utf8');
        //db 접속, 한글 깨질까봐 해준것
        //한글 안깨지면 지워도 됨

        $sql = "select * from join_mem where id = '$id'";
        //sql 에 저장하라 db 에 있는 id 와 같은 받은 id 를

        $result = mysqli_query($connect,$sql);
        //result 는 id=id 인 레코드를 저장
        $num_record = mysqli_num_rows($result);
        //record총 개수를 샘

        if($num_record)
        {
            echo "아이디가 중복됩니다! <br>";
            echo "다른 아이디를 사용하세요.<br>";
        }
        else{
            //numrecord 가 0이면
            echo "사용가능한 아이디입니다.";
        }

        mysqli_close($connect);
    }
?>