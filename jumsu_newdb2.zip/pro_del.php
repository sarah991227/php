<?
   include "dbconn.php";     

$code = $_POST['code'];

   // 필드 num이 $num 값을 가지는 레코드 삭제
   $sql = "delete from product1 where num = $num";  
  mysqli_query( $connect,$sql);

   mysqli_close($connect);
   Header("Location:pro_list.php"); 
?>
