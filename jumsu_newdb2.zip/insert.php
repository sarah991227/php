<?
           session_start();
?>
  <meta charset="utf-8">

<?

include "dbconn.php";       // dconn.php 파일을 불러옴

$code = $_POST['code'];
$name=$_POST['name'];
$cat=$_POST['cat'];
$quant=$_POST['quant'];
$price=$_POST['price'];

$tot = mysqli_query( $connect,$sql);
if($cat == 2)
    $tot = round($price * $quant) * 0.9;
else
    $tot = round($price * $quant);


     $sql = "insert into product1 (code,name,cat,quant,price,tot) values";
     $sql .= "('$code','$name',$cat,$quant,$price,$tot)";

     $result = mysqli_query( $connect,$sql);
 
    mysqli_close($connect);    // DB 접속 끊기
    echo "
    <script>
     location.href = 'pro_list.php';
    </script>
 ";
 
 ?>
  
 </table>
