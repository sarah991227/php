create table product1(
    code varchar(12),
    name varchar(12),
    cat int,
    quant int,
    price int,
    tot float,
    primary key(code)
)