<?
$connect =mysqli_connect("localhost","slee470","Beautiful991227!","slee470") or
    die("SQL server에 연결할 수 없습니다.");
    mysqli_select_db($connect,"slee470");
?>