<?php
    session_start();
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>html5문서</title>
<style>

tr,td {text-align:center;}
table {padding:20px;box-sizing:border-box;}
.tb {border:none;}
tr, td {border:none;}
 
</style>
<body>
    <h3>데이터 입력하기</h3>
    <form action = "insert.php" method = 'post'>
        <table width = "900" border = "1">
            <tr>
                <td>
                    제품코드 : <input type = "text" size = "6" name = "code">
                    수량 : <input type = "text" size = "6" name = "quantity">
                    단가 : <input type = "text" size = "6" name = "price">
                </td>
                <td><input type = "submit" value = "입력하기"></td>
            </tr>
        </table>
    </form>

    <table width = "900" border = "1" class = "tb">
        <!-- 타이틀 -->
        <tr>
            <td>제품코드</td>
            <td>수량</td>
            <td>단가</td>
            <td>판매가격</td>
        </tr>
        <!-- 데이타 들어오기 php -->
        <?
            include "dbconn.php";
            $sql = "select * from product";
            // prouct에 모든 데이타를 검색한다음에 sql 에 저장
            $result = mysqli_query($connect,$sql);
            // 접촉해서 리절트에 저장
            while($row = mysqli_fetch_array($result)){
            // mysqli_fetch_array 함수는 mysqli_query를 통해 얻은 리절트 셋(result set)에서 레코드를 1 개씩 리턴해주는 함수
            //순번을 키로 할 수 도 있고 필드를 키로 할 수 도 있다
            echo "<tr>
            <td> $row[code] </td>
            <td> $row[quantity] </td>
            <td> $row[price] </td>
            <td> $row[total] </td>
            </tr>
            " ;
            }
            mysqli_close($connect);
            // 접속 끊기
        ?>
    </table>
</body>
</html>