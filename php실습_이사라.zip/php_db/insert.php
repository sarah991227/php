<?
    session_start();
?>
<meta charset = "utf-8">
<?
$code = $_POST['code'];
$quantity = $_POST['quantity'];
$price = $_POST['price'];

include "dbconn.php";
$sql = "select * from product";
$result = mysqli_query($connect,$sql);
$total = round($quantity*$price);
// 반올림해서 소수 첫째자리 까지만

$sql = "insert into product(code, quantity, price, total) values";
$sql .= "('$code', $quantity , $price, $total)";
$result = mysqli_query($connect, $sql);
mysqli_close($connect);
echo "
<script>
location.href = 'product.php';
</script>
";
?>