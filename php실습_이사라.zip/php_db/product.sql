create table product(
    code varchar(8),
    -- 5자리 넣으면 3자리 낭비안되고 5자리로 바뀜
    quantity int,
    price float,
    total float,
    primary key(code)
)